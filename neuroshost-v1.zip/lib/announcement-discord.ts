import { decrypt } from "@/lib/crypto";

export function validateDiscordWebhook(value: string): boolean {
  try {
    const url = new URL(value);
    return (url.protocol === "https:" && (url.hostname === "discord.com" || url.hostname === "discordapp.com") && url.pathname.startsWith("/api/webhooks/"));
  } catch { return false; }
}

function htmlToText(value: string): string {
  return value.replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">")
    .replace(/\s+/g, " ").trim();
}

export async function sendAnnouncementToDiscord(input: {
  webhook: string; title: string; description?: string | null; content: string; url: string;
}) {
  const webhook = decrypt(input.webhook);
  if (!validateDiscordWebhook(webhook)) throw new Error("Webhook Discord invalide.");
  const description = htmlToText(input.description || input.content).slice(0, 4096);
  const response = await fetch(webhook, {
    method: "POST",
    headers: { "Content-Type": "application/json", "User-Agent": "Neuroshost-Billing/1.0.0" },
    body: JSON.stringify({
      content: "📢 **Nouvelle annonce Neuroshost**",
      embeds: [{ title: input.title.slice(0, 256), description, url: input.url, color: 0x00c7eb, footer: { text: "Neuroshost Billing" }, timestamp: new Date().toISOString() }],
      allowed_mentions: { parse: [] }
    })
  });
  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`Discord a refusé le webhook (${response.status})${text ? `: ${text.slice(0, 250)}` : ""}`);
  }
}
